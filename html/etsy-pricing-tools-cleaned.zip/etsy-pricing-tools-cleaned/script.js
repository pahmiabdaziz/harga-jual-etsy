// JS dari <script> tag dimasukkan di sini
