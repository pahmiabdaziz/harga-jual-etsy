document.addEventListener("DOMContentLoaded", () => {
  tampilkanRiwayat();
  document.getElementById("modeToggle").addEventListener("change", toggleDarkMode);
});

function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");
}

async function getRealtimeUSD() {
  try {
    const res = await fetch("https://open.er-api.com/v6/latest/USD");
    const data = await res.json();
    const rate = data.rates.IDR;
    document.getElementById("kursRealtime").innerText = `Kurs USD ke IDR saat ini: Rp${rate.toLocaleString()}`;
    return rate;
  } catch {
    const fallback = 16000;
    document.getElementById("kursRealtime").innerText = `Kurs USD ke IDR tidak tersedia, menggunakan nilai default Rp${fallback.toLocaleString()}`;
    return fallback;
  }
}
